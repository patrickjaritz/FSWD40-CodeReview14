<?php

/* bigevents/view.html.twig */
class __TwigTemplate_825102bd58d8a599676bd91a144be87fc6a909d1e7c009a7407e4c705954d801 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "bigevents/view.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevents/view.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bigevents/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "        <a class=\"btn btn-default\" href=\"/\">Back to Events</a>
        <hr>
        <h2 class=\"page-header\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "name", array()), "html", null, true);
        echo "</h2>
          <p>
            <img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "image", array()), "html", null, true);
        echo "\" alt=\"image\">
        </p>

        <ul class=\"list-group\">
                <li class=\"list-group-item\">Start Date: <strong> ";
        // line 12
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "startDate", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </strong> </li>
                 <li class=\"list-group-item\">End Date: <strong> ";
        // line 13
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "endDate", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </strong> </li>
      
                <li class=\"list-group-item\">Type: <strong> ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "type", array()), "html", null, true);
        echo " </strong></li>
                <li class=\"list-group-item\">Capacity: <strong> ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "capacity", array()), "html", null, true);
        echo " </strong></li>
            <li class=\"list-group-item\">Email Contact: <strong> ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "email", array()), "html", null, true);
        echo " </strong></li>
            <li class=\"list-group-item\">Phone Contact: <strong> ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "phone", array()), "html", null, true);
        echo " </strong></li>
            
            <li class=\"list-group-item\">Street: <strong> ";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "addressStreet", array()), "html", null, true);
        echo " </strong></li>
         <li class=\"list-group-item\">City: <strong> ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "addressCode", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "addressCity", array()), "html", null, true);
        echo " </strong></li>
        
      <li class=\"list-group-item\"><a href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute(($context["bigevents"] ?? $this->getContext($context, "bigevents")), "url", array()), "html", null, true);
        echo "\"><strong>Event Link</strong></a></li>
        </ul>
      
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bigevents/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 23,  95 => 21,  91 => 20,  86 => 18,  82 => 17,  78 => 16,  74 => 15,  69 => 13,  65 => 12,  58 => 8,  53 => 6,  49 => 4,  40 => 3,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'base.html.twig' %}
{% block body %}
        <a class=\"btn btn-default\" href=\"/\">Back to Events</a>
        <hr>
        <h2 class=\"page-header\">{{bigevents.name}}</h2>
          <p>
            <img src=\"{{bigevents.image}}\" alt=\"image\">
        </p>

        <ul class=\"list-group\">
                <li class=\"list-group-item\">Start Date: <strong> {{bigevents.startDate|date('F j, Y, g:i a')}} </strong> </li>
                 <li class=\"list-group-item\">End Date: <strong> {{bigevents.endDate|date('F j, Y, g:i a')}} </strong> </li>
      
                <li class=\"list-group-item\">Type: <strong> {{bigevents.type}} </strong></li>
                <li class=\"list-group-item\">Capacity: <strong> {{bigevents.capacity}} </strong></li>
            <li class=\"list-group-item\">Email Contact: <strong> {{bigevents.email}} </strong></li>
            <li class=\"list-group-item\">Phone Contact: <strong> {{bigevents.phone}} </strong></li>
            
            <li class=\"list-group-item\">Street: <strong> {{bigevents.addressStreet}} </strong></li>
         <li class=\"list-group-item\">City: <strong> {{bigevents.addressCode}} {{bigevents.addressCity}} </strong></li>
        
      <li class=\"list-group-item\"><a href=\"{{bigevents.url}}\"><strong>Event Link</strong></a></li>
        </ul>
      
{% endblock %}", "bigevents/view.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/cr14_patrick_jaritz_bigevents/app/Resources/views/bigevents/view.html.twig");
    }
}
